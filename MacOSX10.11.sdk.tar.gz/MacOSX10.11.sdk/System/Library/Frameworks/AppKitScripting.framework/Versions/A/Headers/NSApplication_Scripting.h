/*
        NSApplication_Scripting.h
        AppKitScripting Framework
        Copyright (c) 1997-2000, Apple Computer, Inc.
        All rights reserved.
*/

// Everything that was once in the AppKitScripting framework has been moved to the AppKit framework.
#import <AppKit/NSApplicationScripting.h>
